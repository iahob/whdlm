//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GameServer.RC
//

// �¶������һЩĬ��ֵ
// 
#define IDR_MAINFRAME                   128
#define IDD_CUSTOM_RULE                 4000
#define IDC_TAB_CUSTOM                  4001
#define IDD_CUSTOM_GENERAL              4002
#define IDD_CUSTOM_ANDROID              4003
#define IDC_EDIT_GENERAL_1              4100
#define IDC_EDIT_GENERAL_2              4101
#define IDC_EDIT_GENERAL_3              4102
#define IDC_EDIT_GENERAL_4              4103
#define IDC_EDIT_GENERAL_5              4104
#define IDC_EDIT_GENERAL_6              4105
#define IDC_EDIT_GENERAL_7              4106
#define IDC_EDIT_GENERAL_8              4107
#define IDC_EDIT_GENERAL_9              4108
#define IDC_EDIT_GENERAL_10             4109
#define IDC_EDIT_GENERAL_11             4110
#define IDC_EDIT_GENERAL_12             4111
#define IDC_EDIT_GENERAL_13             4112
#define IDC_EDIT_GENERAL_14             4113
#define IDC_EDIT_GENERAL_15             4114
#define IDC_EDIT_GENERAL_16             4115
#define IDC_EDIT_GENERAL_17             4116
#define IDC_EDIT_GENERAL_18             4117
#define IDC_EDIT_GENERAL_19             4118
#define IDC_EDIT_GENERAL_20             4119
#define IDC_CHECK_GENERAL_1             4120
#define IDC_RADIO_SUPERBANKER_VIP       4121
#define IDC_RADIO_SUPERBANKER_CONSUME   4122
#define IDC_COMBO_SUPERBANKER_VIP       4123
#define IDC_EDIT_SUPERBANKERCONSUME     4124
#define IDC_RADIO_OCCUPYSEAT_VIP        4125
#define IDC_RADIO_OCCUPYSEAT_CONSUME    4126
#define IDC_COMBO_OCCUPYSEAT_VIP        4127
#define IDC_EDIT_OCCUPYSEATCONSUME      4128
#define IDC_RADIO_OCCUPYSEAT_FREE       4129
#define IDC_EDIT_OCCUPYSEATFREE         4130
#define IDC_EDIT_FORCESTANDUP           4131
#define IDC_EDIT_ANDROID_1              4200
#define IDC_EDIT_ANDROID_2              4201
#define IDC_EDIT_ANDROID_3              4202
#define IDC_EDIT_ANDROID_4              4203
#define IDC_EDIT_ANDROID_5              4204
#define IDC_EDIT_ANDROID_6              4205
#define IDC_EDIT_ANDROID_7              4206
#define IDC_EDIT_ANDROID_8              4207
#define IDC_EDIT_ANDROID_9              4208
#define IDC_EDIT_ANDROID_10             4209
#define IDC_EDIT_ANDROID_11             4210
#define IDC_EDIT_ANDROID_12             4211
#define IDC_EDIT_ANDROID_13             4212
#define IDC_EDIT_ANDROID_14             4213
#define IDC_EDIT_ANDROID_15             4214
#define IDC_EDIT_ANDROID_16             4215
#define IDC_EDIT_ANDROID_17             4216
#define IDC_EDIT_ANDROID_18             4217
#define IDC_EDIT_ANDROID_19             4218
#define IDC_EDIT_ANDROID_20             4219
#define IDC_CHECK_ANDROID_1             4220
#define IDC_EDIT_ANDROID_21             4221
#define IDC_EDIT_ANDROID_22             4222
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE	4000
#define _APS_NEXT_CONTROL_VALUE		4000
#define _APS_NEXT_SYMED_VALUE		4000
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
