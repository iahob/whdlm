//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� ClientControl.rc ʹ��
//
#define IDD_DIALOG_ADMIN                3000
#define IDC_BTN_UPDATE_STORAGE          3100
#define IDC_EDIT_STORAGE_START          3101
#define IDC_EDIT_STORAGE_DEDUCT         3102
#define IDC_EDIT_STORAGE_CURRENT        3103
#define IDC_EDIT_STORAGE_MAX1           3104
#define IDC_EDIT_STORAGE_MUL1           3105
#define IDC_EDIT_STORAGE_MAX2           3106
#define IDC_EDIT_STORAGE_MUL2           3107
#define IDC_BTN_UPDATE_STORAGE2         3108
#define IDC_BT_RESET                    3200
#define IDC_BT_CURSET                   3201
#define IDC_BT_EXCUTE                   3202
#define IDC_COMBO_TIMES                 3204
#define IDC_RADIO_WIN                   3205
#define IDC_RADIO_LOSE                  3206
#define IDC_RADIO_CT_BANKER             3207
#define IDC_RADIO_CT_AREA               3208
#define IDC_CHECK_TIAN                  3209
#define IDC_CHECK_DI                    3210
#define IDC_CHECK_XUAN                  3211
#define IDC_CHECK_HUANG                 3212
#define IDC_CHECK_XUAN2                 3212
#define IDC_CHECK_WANG                  3213
#define IDC_LIST_USER_BET               3300
#define IDC_EDIT_USER_ID                3301
#define IDC_BTN_USER_BET_QUERY          3302
#define IDC_BTN_USER_BET_ALL            3303
#define IDC_LIST_USER_BET_ALL           3304
#define IDC_STATIC_CONTROL_INFO         3305

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        3305
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         3306
#define _APS_NEXT_SYMED_VALUE           3304
#endif
#endif
